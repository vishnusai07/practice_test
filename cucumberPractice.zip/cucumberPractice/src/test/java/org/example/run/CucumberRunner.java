package org.example.run;

import io.cucumber.junit.Cucumber;
import org.junit.runner.RunWith;



@RunWith(Cucumber.class)
public class CucumberRunner {
}
